from django.apps import AppConfig


class PpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pp'
