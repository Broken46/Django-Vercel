from card.wsgi import application

# Vercel requires the variable to be named `app`
app = application
